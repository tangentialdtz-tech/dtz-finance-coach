/* Core finance logic for the FUTMinna Personal Finance Coach (built by DTZ TRIO).
   Pure functions, no DOM access, so it is easy to test in Node. */
(function (root) {
  'use strict';

  const CURRENCY = '₦';
  const TYPES = ['Income', 'Expense', 'Savings'];
  const INCOME_SOURCES = [
    'Allowance / Parents', 'Part-time / Gig', 'Scholarship / Bursary',
    'Business / Hustle', 'Gift', 'Other Income',
  ];
  const NEEDS = [
    'Food & Provisions', 'Transport', 'Hostel & Rent', 'Data & Airtime',
    'Academics (Handouts, Printing, Books)', 'Toiletries & Laundry', 'Health',
  ];
  const WANTS = [
    'Entertainment & Outings', 'Clothing & Beauty', 'Subscriptions & Games',
    'Gifts & Donations', 'Other Wants',
  ];
  const EXPENSE_CATEGORIES = NEEDS.concat(WANTS);

  const CATEGORY_TIPS = {
    'Food & Provisions': 'Food is your biggest lever. Buy staples (rice, beans, garri, noodles, eggs) in bulk at the market and cook with roommates instead of buying daily from cafeterias.',
    'Transport': 'Walk or share rides for short routes, bundle errands into one trip, and avoid last-minute charters.',
    'Data & Airtime': 'Compare bundles before buying, use night or weekly plans, and download materials on campus Wi-Fi.',
    'Entertainment & Outings': "Set a fixed weekly 'fun money' amount in cash or a separate wallet, and stop when it is finished.",
    'Clothing & Beauty': 'Delay non-urgent purchases by 7 days. If you still want it after a week, buy it.',
    'Subscriptions & Games': 'Audit recurring subscriptions and in-game spending. Cancel anything you did not use this month.',
    'Hostel & Rent': 'Rent is fixed, so protect it first. Set it aside the day money arrives.',
    'Academics (Handouts, Printing, Books)': 'Share handouts and printing costs with classmates and prefer soft copies where allowed.',
  };

  /* ---------- helpers ---------- */
  const pad = (n) => String(n).padStart(2, '0');
  function toISO(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseISO(s) { const p = String(s).split('-').map(Number); return new Date(Date.UTC(p[0], p[1] - 1, p[2])); }
  function isValidDate(s) { return /^\d{4}-\d{2}-\d{2}$/.test(s) && !isNaN(parseISO(s).getTime()); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function money(x) {
    const n = Math.round(Number(x) || 0);
    return (n < 0 ? '-' : '') + CURRENCY + Math.abs(n).toLocaleString('en-US');
  }
  function pct(x) { return Math.round((x || 0) * 100) + '%'; }
  function titleCase(s) {
    s = String(s || '').trim().toLowerCase();
    return s ? s[0].toUpperCase() + s.slice(1) : '';
  }

  /* ---------- cleaning / validation ---------- */
  function cleanRows(rows) {
    const out = [];
    (rows || []).forEach(function (r) {
      const date = String(r.date || '').trim().slice(0, 10);
      const type = titleCase(r.type);
      const amount = Number(String(r.amount == null ? '' : r.amount).replace(/[₦,\s]/g, ''));
      if (!isValidDate(date) || TYPES.indexOf(type) < 0 || !isFinite(amount) || amount <= 0) return;
      out.push({
        id: r.id || uid(), date: date, type: type,
        category: String(r.category || '').trim() || (type === 'Income' ? 'Other Income' : type === 'Savings' ? 'General Savings' : 'Other Wants'),
        amount: amount, note: String(r.note || '').trim(),
      });
    });
    out.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
    return out;
  }

  function filterPeriod(txs, start, end) {
    return txs.filter(function (t) { return (!start || t.date >= start) && (!end || t.date <= end); });
  }

  /* ---------- summaries ---------- */
  function sum(txs, pred) { return txs.reduce(function (a, t) { return pred(t) ? a + t.amount : a; }, 0); }

  function summarize(txs) {
    const income = sum(txs, function (t) { return t.type === 'Income'; });
    const expenses = sum(txs, function (t) { return t.type === 'Expense'; });
    const savings = sum(txs, function (t) { return t.type === 'Savings'; });
    const needs = sum(txs, function (t) { return t.type === 'Expense' && NEEDS.indexOf(t.category) >= 0; });
    const wants = expenses - needs;
    return {
      income: income, expenses: expenses, savings: savings, needs: needs, wants: wants,
      balance: income - expenses - savings,
      savingsRate: income ? savings / income : 0,
      needsShare: income ? needs / income : 0,
      wantsShare: income ? wants / income : 0,
    };
  }

  function categoryBreakdown(txs) {
    const m = {};
    txs.forEach(function (t) { if (t.type === 'Expense') m[t.category] = (m[t.category] || 0) + t.amount; });
    return Object.keys(m).map(function (k) { return [k, m[k]]; }).sort(function (a, b) { return b[1] - a[1]; });
  }

  function dailySpend(txs) {
    const m = {};
    txs.forEach(function (t) { if (t.type === 'Expense') m[t.date] = (m[t.date] || 0) + t.amount; });
    return Object.keys(m).sort().map(function (k) { return [k, m[k]]; });
  }

  function budgetPlan(income, needsPct, wantsPct, savingsPct) {
    return { Needs: income * needsPct / 100, Wants: income * wantsPct / 100, Savings: income * savingsPct / 100 };
  }

  function generateTips(s, breakdown, p) {
    const tips = [];
    const needsPct = p[0], wantsPct = p[1], savingsPct = p[2];
    if (s.income <= 0) return ['Log your income (allowance, gig, bursary) first so I can build a budget around it.'];
    if (s.balance < 0) {
      tips.push('You have spent or saved ' + money(-s.balance) + ' more than you earned in this period. Pause wants for the rest of the period and cover only needs until income comes in.');
    }
    if (s.needsShare * 100 > needsPct) {
      tips.push('Needs take ' + pct(s.needsShare) + ' of your income (target about ' + needsPct + '%). Look at food and data first; they are the easiest to trim.');
    }
    if (s.wantsShare * 100 > wantsPct) {
      tips.push('Wants take ' + pct(s.wantsShare) + ' of your income (target about ' + wantsPct + '%). Set a weekly fun-money limit and keep it separate.');
    }
    if (s.savingsRate * 100 < savingsPct) {
      tips.push('You are saving ' + pct(s.savingsRate) + ' of income. Aim for ' + savingsPct + '% (about ' + money(s.income * savingsPct / 100) + '). Move it the day money arrives, before you spend.');
    } else {
      tips.push('Nice work. You are saving ' + pct(s.savingsRate) + ' of your income. Keep the habit going.');
    }
    if (breakdown.length) {
      const top = breakdown[0][0];
      const share = breakdown[0][1] / Math.max(s.expenses, 1);
      tips.push('Your biggest spend is ' + top + ' (' + pct(share) + ' of expenses). ' + (CATEGORY_TIPS[top] || 'Review the individual items in this category for savings.'));
    }
    return tips;
  }

  function goalProgress(goal, txs, todayISO) {
    const saved = sum(txs, function (t) { return t.type === 'Savings' && t.category === goal.name; });
    const target = Number(goal.target);
    const remaining = Math.max(target - saved, 0);
    const daysLeft = Math.round((parseISO(goal.deadline) - parseISO(todayISO)) / 86400000);
    const monthsLeft = daysLeft > 0 ? Math.max(1, Math.ceil(daysLeft / 30)) : 0;
    return {
      id: goal.id, name: goal.name, target: target, saved: saved, remaining: remaining,
      pct: target ? Math.min(saved / target, 1) : 0,
      deadline: goal.deadline, monthsLeft: monthsLeft,
      perMonth: monthsLeft ? remaining / monthsLeft : remaining,
      overdue: daysLeft <= 0 && remaining > 0,
    };
  }

  /* ---------- CSV ---------- */
  function csvCell(v) {
    const s = String(v == null ? '' : v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }
  function toCSV(txs) {
    const head = 'date,type,category,amount,note';
    return [head].concat(txs.map(function (t) {
      return [t.date, t.type, t.category, t.amount, t.note].map(csvCell).join(',');
    })).join('\n');
  }
  function parseCSV(text) {
    text = String(text || '').replace(/^﻿/, '');
    const rows = [];
    let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; }
        else if (c === '"') q = false;
        else cell += c;
      } else if (c === '"') q = true;
      else if (c === ',') { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = '';
        if (row.some(function (x) { return x !== ''; })) rows.push(row);
        row = [];
      } else cell += c;
    }
    row.push(cell);
    if (row.some(function (x) { return x !== ''; })) rows.push(row);
    if (!rows.length) return [];
    const head = rows[0].map(function (h) { return h.trim().toLowerCase(); });
    return rows.slice(1).map(function (r) {
      const o = {};
      head.forEach(function (h, i) { o[h] = r[i]; });
      return o;
    });
  }

  const api = {
    CURRENCY, TYPES, INCOME_SOURCES, NEEDS, WANTS, EXPENSE_CATEGORIES, CATEGORY_TIPS,
    toISO, parseISO, isValidDate, uid, money, pct, cleanRows, filterPeriod, summarize,
    categoryBreakdown, dailySpend, budgetPlan, generateTips, goalProgress, toCSV, parseCSV,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Finance = api;
})(typeof window !== 'undefined' ? window : globalThis);
