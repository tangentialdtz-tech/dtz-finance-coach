/* FUTMinna Personal Finance Coach: UI logic. Built by DTZ TRIO. */
(function () {
  'use strict';
  const F = window.Finance;
  const C = window.Coach;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- storage ---------- */
  const STORE = 'dtz_fc_v1';
  const KEY_STORE = 'dtz_fc_key';
  const defaults = () => ({ txs: [], goals: [], needs: 60, wants: 25, period: 'month', model: 'gpt-4o-mini' });
  function load() {
    try {
      const s = JSON.parse(localStorage.getItem(STORE) || 'null');
      const st = Object.assign(defaults(), s || {});
      st.txs = F.cleanRows(st.txs);
      st.goals = (st.goals || []).filter((g) => g && g.name && Number(g.target) > 0 && F.isValidDate(g.deadline));
      return st;
    } catch (e) { return defaults(); }
  }
  let state = load();
  function save() { try { localStorage.setItem(STORE, JSON.stringify(state)); } catch (e) { /* storage full or blocked */ } }
  const getKey = () => { try { return localStorage.getItem(KEY_STORE) || ''; } catch (e) { return ''; } };

  let chat = [];
  let busy = false;
  let last = null;

  const today = () => F.toISO(new Date());

  /* ---------- toast ---------- */
  let toastTimer;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
  }

  /* ---------- period ---------- */
  function periodRange() {
    const now = new Date();
    if (state.period === 'month') {
      const label = now.toLocaleString('en-GB', { month: 'long', year: 'numeric' });
      return { start: F.toISO(new Date(now.getFullYear(), now.getMonth(), 1)), end: today(), label: label };
    }
    if (state.period === '30d') {
      const d = new Date(now); d.setDate(d.getDate() - 30);
      return { start: F.toISO(d), end: today(), label: 'Last 30 days' };
    }
    return { start: null, end: null, label: 'All time' };
  }

  function compute() {
    const r = periodRange();
    const view = F.filterPeriod(state.txs, r.start, r.end);
    const s = F.summarize(view);
    const bd = F.categoryBreakdown(view);
    const savingsPct = Math.max(0, 100 - state.needs - state.wants);
    const pcts = [state.needs, state.wants, savingsPct];
    const plan = F.budgetPlan(s.income, state.needs, state.wants, savingsPct);
    const goals = state.goals.map((g) => F.goalProgress(g, state.txs, today()));
    return { r, view, s, bd, savingsPct, pcts, plan, goals };
  }

  /* ---------- count-up ---------- */
  function animateCount(el, to) {
    const from = Number(el.dataset.v || 0);
    if (from === to && el.textContent !== '') { el.textContent = to; return; }
    el.dataset.v = to;
    if (reduced) { el.textContent = to; return; }
    const t0 = performance.now(), dur = 1200;
    (function step(t) {
      const p = Math.min(1, (t - t0) / dur);
      el.textContent = Math.round(from + (to - from) * (1 - Math.pow(1 - p, 3)));
      if (p < 1) requestAnimationFrame(step);
    })(t0);
  }

  /* ---------- renderers ---------- */
  function renderStats() {
    animateCount($('#stat-tx'), state.txs.length);
    animateCount($('#stat-goals'), state.goals.length);
    animateCount($('#stat-cats'), F.EXPENSE_CATEGORIES.length);
  }

  function renderSettings(c) {
    $('#period').value = state.period;
    $('#needs').value = state.needs; $('#wants').value = state.wants;
    $('#needs-val').textContent = state.needs; $('#wants-val').textContent = state.wants;
    $('#savings-val').textContent = c.savingsPct;
    $('#split-warn').hidden = state.needs + state.wants <= 100;
  }

  function shortMoney(n) {
    if (n >= 1e6) return F.CURRENCY + (n / 1e6).toFixed(1) + 'M';
    if (n >= 1e3) return F.CURRENCY + Math.round(n / 1e3) + 'k';
    return F.CURRENCY + Math.round(n);
  }

  function dailySVG(days) {
    const W = 600, H = 210, L = 46, R = 12, T = 12, B = 30;
    const pw = W - L - R, ph = H - T - B;
    const max = Math.max.apply(null, days.map((d) => d[1]));
    const t0 = F.parseISO(days[0][0]).getTime();
    const t1 = F.parseISO(days[days.length - 1][0]).getTime();
    const x = (d) => L + (t1 === t0 ? pw / 2 : ((F.parseISO(d).getTime() - t0) / (t1 - t0)) * pw);
    const y = (v) => T + ph - (v / max) * ph;
    const pts = days.map((d) => x(d[0]).toFixed(1) + ',' + y(d[1]).toFixed(1));
    let grid = '';
    [0, 0.5, 1].forEach((f) => {
      const gy = (T + ph - f * ph).toFixed(1);
      grid += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + gy + '" y2="' + gy + '" stroke="#2A2A2A"/>' +
        '<text x="' + (L - 6) + '" y="' + (Number(gy) + 4) + '" text-anchor="end" fill="#888" font-size="11">' + shortMoney(max * f) + '</text>';
    });
    const fmt = (d) => F.parseISO(d).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: 'UTC' });
    let body;
    if (days.length === 1) {
      body = '<circle cx="' + x(days[0][0]) + '" cy="' + y(days[0][1]) + '" r="4" fill="#E5E5E5"/>';
    } else {
      const area = L + ',' + (T + ph) + ' ' + pts.join(' ') + ' ' + (W - R) + ',' + (T + ph);
      body = '<polygon points="' + area + '" fill="url(#g)"/><polyline points="' + pts.join(' ') + '" fill="none" stroke="#E5E5E5" stroke-width="2" stroke-linejoin="round" stroke-linecap="round"/>' +
        days.map((d) => '<circle cx="' + x(d[0]).toFixed(1) + '" cy="' + y(d[1]).toFixed(1) + '" r="3" fill="#fff"/>').join('');
    }
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Daily spending chart"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".18"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient></defs>' +
      grid + body +
      '<text x="' + L + '" y="' + (H - 8) + '" fill="#888" font-size="11">' + fmt(days[0][0]) + '</text>' +
      (days.length > 1 ? '<text x="' + (W - R) + '" y="' + (H - 8) + '" text-anchor="end" fill="#888" font-size="11">' + fmt(days[days.length - 1][0]) + '</text>' : '') +
      '</svg>';
  }

  function renderDashboard(c) {
    const empty = c.view.length === 0;
    $('#dash-empty').hidden = !empty;
    $('#dash-body').hidden = empty;
    if (empty) return;
    const s = c.s;
    $('#metrics').innerHTML =
      '<div class="metric"><div class="k">Income</div><div class="v">' + F.money(s.income) + '</div></div>' +
      '<div class="metric"><div class="k">Expenses</div><div class="v">' + F.money(s.expenses) + '</div></div>' +
      '<div class="metric"><div class="k">Saved</div><div class="v">' + F.money(s.savings) + '</div><div class="d">' + F.pct(s.savingsRate) + ' of income</div></div>' +
      '<div class="metric"><div class="k">Balance left</div><div class="v">' + F.money(s.balance) + '</div></div>';

    const rows = [['Needs', c.plan.Needs, s.needs], ['Wants', c.plan.Wants, s.wants], ['Savings', c.plan.Savings, s.savings]];
    $('#budget-table').innerHTML = '<thead><tr><th>Bucket</th><th class="n">Planned</th><th class="n">Actual</th><th class="n">Difference</th></tr></thead><tbody>' +
      rows.map((r) => '<tr><td>' + r[0] + '</td><td class="n">' + F.money(r[1]) + '</td><td class="n">' + F.money(r[2]) + '</td><td class="n">' + F.money(r[1] - r[2]) + '</td></tr>').join('') + '</tbody>';

    const max = c.bd.length ? c.bd[0][1] : 1;
    $('#cat-chart').innerHTML = c.bd.length
      ? c.bd.map((b) => '<div class="bar-row"><div class="bar-top"><span>' + esc(b[0]) + '</span><b>' + F.money(b[1]) + '</b></div><div class="bar"><i data-w="' + (b[1] / max * 100).toFixed(1) + '"></i></div></div>').join('')
      : '<p class="chart-empty">No expenses logged.</p>';
    requestAnimationFrame(() => $$('#cat-chart .bar > i').forEach((i) => { i.style.width = i.dataset.w + '%'; }));

    const days = F.dailySpend(c.view);
    $('#day-chart').innerHTML = days.length ? '<div class="line">' + dailySVG(days) + '</div>' : '<p class="chart-empty">No expenses logged.</p>';

    $('#tips').innerHTML = F.generateTips(s, c.bd, c.pcts).map((t) => '<li>' + esc(t) + '</li>').join('');
  }

  function categoryOptions(type) {
    if (type === 'Income') return F.INCOME_SOURCES;
    if (type === 'Expense') return F.EXPENSE_CATEGORIES;
    return state.goals.map((g) => g.name).concat(['General Savings']);
  }
  function renderCategories() {
    const type = $('input[name=type]:checked').value;
    const sel = $('#tx-category');
    const prev = sel.value;
    const opts = categoryOptions(type);
    sel.innerHTML = opts.map((o) => '<option>' + esc(o) + '</option>').join('');
    if (opts.indexOf(prev) >= 0) sel.value = prev;
  }

  function renderGoals(c) {
    const list = $('#goal-list');
    if (!c.goals.length) {
      list.innerHTML = '<div class="card empty" style="margin-top:16px"><p>No goals yet. Create one, then log <b>Savings</b> transactions under its name.</p></div>';
      return;
    }
    list.innerHTML = c.goals.map((g) => {
      let msg;
      if (g.pct >= 1) msg = 'Goal reached!';
      else if (g.overdue) msg = 'Deadline has passed. Consider creating the goal again with a new date.';
      else msg = 'By ' + new Date(g.deadline + 'T00:00:00').toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) +
        ': save about ' + F.money(g.perMonth) + ' per month (' + g.monthsLeft + ' month' + (g.monthsLeft === 1 ? '' : 's') + ' left).';
      return '<div class="card goal"><div class="goal-top"><b>' + esc(g.name) + '</b><span>' + F.money(g.saved) + ' of ' + F.money(g.target) + '</span></div>' +
        '<div class="bar"><i style="width:' + (g.pct * 100).toFixed(1) + '%"></i></div>' +
        '<div class="goal-top"><span class="small">' + msg + '</span><button class="btn btn-ghost btn-sm" data-del-goal="' + esc(g.id) + '">Remove goal</button></div></div>';
    }).join('');
  }

  function renderData() {
    const txs = state.txs.slice().reverse();
    if (!txs.length) { $('#tx-table').innerHTML = '<tbody><tr><td>Nothing logged yet.</td></tr></tbody>'; return; }
    const shown = txs.slice(0, 100);
    $('#tx-table').innerHTML = '<thead><tr><th>Date</th><th>Type</th><th>Category</th><th class="n">Amount</th><th>Note</th><th></th></tr></thead><tbody>' +
      shown.map((t) => '<tr><td>' + t.date + '</td><td>' + t.type + '</td><td>' + esc(t.category) + '</td><td class="n">' + F.money(t.amount) + '</td><td class="note">' + esc(t.note) + '</td><td><button class="x" data-del-tx="' + esc(t.id) + '" aria-label="Delete transaction">×</button></td></tr>').join('') +
      '</tbody>' + (txs.length > 100 ? '<tfoot><tr><td colspan="6" class="small">Showing the latest 100 of ' + txs.length + '. Download the CSV for everything.</td></tr></tfoot>' : '');
  }

  function mdLite(text) {
    const lines = esc(text).split('\n');
    let html = '', inList = false;
    lines.forEach((ln) => {
      const m = ln.match(/^\s*(?:[-*•]|\d+[.)])\s+(.*)$/);
      const fmt = (s) => s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
      if (m) { if (!inList) { html += '<ul>'; inList = true; } html += '<li>' + fmt(m[1]) + '</li>'; }
      else { if (inList) { html += '</ul>'; inList = false; } if (ln.trim()) html += '<p>' + fmt(ln) + '</p>'; }
    });
    return html + (inList ? '</ul>' : '');
  }

  function renderChat() {
    const box = $('#chat');
    box.innerHTML = chat.map((m) => '<div class="msg ' + m.role + (m.pending ? ' pending' : '') + '">' + (m.role === 'user' ? '<p>' + esc(m.content) + '</p>' : mdLite(m.content)) + '</div>').join('');
  }

  function render() {
    last = compute();
    renderStats();
    renderSettings(last);
    renderDashboard(last);
    renderCategories();
    renderGoals(last);
    renderData();
  }

  /* ---------- tabs ---------- */
  function switchTab(name) {
    $$('.tab').forEach((t) => { const on = t.dataset.tab === name; t.classList.toggle('active', on); t.setAttribute('aria-selected', on); });
    $$('.panel').forEach((p) => { p.hidden = p.id !== 'tab-' + name; });
  }

  /* ---------- sample data ---------- */
  const SAMPLE = [
    [14, 'Income', 'Allowance / Parents', 60000, 'Monthly allowance'], [12, 'Income', 'Part-time / Gig', 12000, 'Logo design gig'],
    [13, 'Expense', 'Hostel & Rent', 15000, 'Hostel levy'], [13, 'Expense', 'Food & Provisions', 9500, 'Foodstuff from market'],
    [11, 'Expense', 'Data & Airtime', 5000, 'Monthly data bundle'], [10, 'Expense', 'Transport', 1500, 'Keke to campus'],
    [9, 'Expense', 'Academics (Handouts, Printing, Books)', 2500, 'Handouts and printing'], [8, 'Expense', 'Food & Provisions', 3000, 'Cafeteria'],
    [7, 'Expense', 'Entertainment & Outings', 4000, 'Hangout'], [6, 'Expense', 'Toiletries & Laundry', 2500, 'Toiletries'],
    [5, 'Expense', 'Food & Provisions', 4000, 'Cooking with roommates'], [4, 'Expense', 'Subscriptions & Games', 2000, 'Game top-up'],
    [3, 'Expense', 'Transport', 1200, 'Rides'], [2, 'Expense', 'Clothing & Beauty', 6000, 'Shoes'],
    [1, 'Expense', 'Food & Provisions', 3500, 'Weekend meals'], [1, 'Savings', 'General Savings', 5000, 'Pay yourself first'],
    [0, 'Expense', 'Entertainment & Outings', 3000, 'Outing'],
  ];
  function loadSample() {
    const rows = SAMPLE.map((s) => { const d = new Date(); d.setDate(d.getDate() - s[0]); return { date: F.toISO(d), type: s[1], category: s[2], amount: s[3], note: s[4] }; });
    const added = mergeRows(rows);
    state.period = '30d';
    save(); render();
    toast(added ? 'Sample data loaded' : 'Sample data already loaded');
  }
  const sig = (t) => [t.date, t.type, t.category, t.amount, t.note].join('|');
  function mergeRows(rows) {
    const have = new Set(state.txs.map(sig));
    const fresh = F.cleanRows(rows).filter((t) => !have.has(sig(t)));
    state.txs = F.cleanRows(state.txs.concat(fresh));
    return fresh.length;
  }

  /* ---------- chat ---------- */
  async function sendChat(q) {
    q = q.trim();
    if (!q || busy) return;
    busy = true; $('#chat-send').disabled = true;
    const history = chat.filter((m) => !m.pending).slice(-8).map((m) => ({ role: m.role, content: m.content }));
    chat.push({ role: 'user', content: q });
    const pend = { role: 'assistant', content: 'Thinking...', pending: true };
    chat.push(pend); renderChat();
    const c = compute();
    let reply;
    try {
      const key = getKey();
      reply = key ? await C.ask(key, state.model, q, C.buildContext(c.r.label, c.s, c.bd, c.goals, c.pcts), history) : C.fallbackAnswer(c.s, c.bd, c.pcts);
    } catch (e) {
      reply = "I couldn't reach the AI service (" + e.message + '). Here are rule-based tips instead:\n\n' + C.fallbackAnswer(c.s, c.bd, c.pcts);
    }
    pend.content = reply; pend.pending = false;
    busy = false; $('#chat-send').disabled = false;
    renderChat();
  }

  /* ---------- events ---------- */
  function bind() {
    $$('.tab').forEach((t) => t.addEventListener('click', () => switchTab(t.dataset.tab)));
    document.addEventListener('click', (e) => {
      const go = e.target.closest('[data-go]');
      if (go) switchTab(go.dataset.go);
      const dt = e.target.closest('[data-del-tx]');
      if (dt) { state.txs = state.txs.filter((t) => t.id !== dt.dataset.delTx); save(); render(); toast('Transaction deleted'); }
      const dg = e.target.closest('[data-del-goal]');
      if (dg && confirm('Remove this goal? Your savings transactions stay in your data.')) { state.goals = state.goals.filter((g) => g.id !== dg.dataset.delGoal); save(); render(); }
    });

    $('#period').addEventListener('change', (e) => { state.period = e.target.value; save(); render(); });
    $('#needs').addEventListener('input', (e) => { state.needs = Number(e.target.value); save(); render(); });
    $('#wants').addEventListener('input', (e) => { state.wants = Number(e.target.value); save(); render(); });

    $$('input[name=type]').forEach((r) => r.addEventListener('change', renderCategories));
    $('#tx-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const amount = Number($('#tx-amount').value);
      const date = $('#tx-date').value;
      if (!(amount > 0)) return toast('Enter an amount greater than 0');
      if (!F.isValidDate(date)) return toast('Pick a valid date');
      const type = $('input[name=type]:checked').value;
      state.txs = F.cleanRows(state.txs.concat([{ date: date, type: type, category: $('#tx-category').value, amount: amount, note: $('#tx-note').value }]));
      save(); render();
      $('#tx-amount').value = ''; $('#tx-note').value = '';
      toast('Added ' + type.toLowerCase() + ' of ' + F.money(amount));
    });

    $('#goal-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const name = $('#goal-name').value.trim();
      const target = Number($('#goal-target').value);
      const deadline = $('#goal-deadline').value;
      if (!name || !(target > 0) || !F.isValidDate(deadline)) return toast('Give the goal a name, a target and a deadline');
      if (state.goals.some((g) => g.name.toLowerCase() === name.toLowerCase())) return toast('You already have a goal with that name');
      state.goals.push({ id: F.uid(), name: name, target: target, deadline: deadline });
      save(); render(); e.target.reset(); setDefaultDates();
      toast('Goal created');
    });

    $('#api-model').addEventListener('change', (e) => { state.model = e.target.value.trim() || 'gpt-4o-mini'; save(); });
    $('#key-save').addEventListener('click', () => {
      const v = $('#api-key').value.trim();
      if (!v) return toast('Paste a key first');
      try { localStorage.setItem(KEY_STORE, v); } catch (e) { return toast('Could not save the key in this browser'); }
      $('#api-key').value = ''; keyStatus(); toast('Key saved on this device');
    });
    $('#key-clear').addEventListener('click', () => { try { localStorage.removeItem(KEY_STORE); } catch (e) { /* ignore */ } keyStatus(); toast('Key removed'); });
    $('#chat-form').addEventListener('submit', (e) => { e.preventDefault(); const i = $('#chat-input'); const q = i.value; i.value = ''; sendChat(q); });
    $('#quick').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) sendChat(b.textContent); });

    $('#csv-download').addEventListener('click', () => {
      const blob = new Blob([F.toCSV(state.txs)], { type: 'text/csv' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob); a.download = 'my_transactions.csv';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    });
    $('#csv-file').addEventListener('change', (e) => {
      const f = e.target.files[0]; if (!f) return;
      const rd = new FileReader();
      rd.onload = () => {
        const parsed = F.parseCSV(String(rd.result));
        const added = mergeRows(parsed);
        save(); render();
        toast(added ? 'Imported ' + added + ' row' + (added === 1 ? '' : 's') : 'No new valid rows found');
      };
      rd.onerror = () => toast('Could not read that file');
      rd.readAsText(f); e.target.value = '';
    });
    $('#load-sample').addEventListener('click', loadSample);
    $('#empty-sample').addEventListener('click', loadSample);
    $('#clear-all').addEventListener('click', () => {
      if (confirm('Delete all transactions and goals on this device? This cannot be undone.')) { state.txs = []; state.goals = []; save(); render(); toast('All data cleared'); }
    });
  }

  function keyStatus() { $('#key-status').textContent = getKey() ? 'A key is saved on this device.' : 'No key saved.'; }
  function setDefaultDates() {
    $('#tx-date').value = today();
    const d = new Date(); d.setDate(d.getDate() + 90);
    $('#goal-deadline').value = F.toISO(d);
  }

  /* ---------- hero effects ---------- */
  function typing() {
    const el = $('#typed');
    const phrases = ["console.log('Hello FUTMINNA')", 'Coding The Future...'];
    if (reduced) { el.textContent = phrases[0]; return; }
    let p = 0, i = 0, del = false;
    (function tick() {
      const s = phrases[p];
      el.textContent = s.slice(0, i);
      if (!del && i === s.length) { del = true; return setTimeout(tick, 1500); }
      if (del && i === 0) { del = false; p = (p + 1) % phrases.length; return setTimeout(tick, 400); }
      i += del ? -1 : 1;
      setTimeout(tick, del ? 35 : 70);
    })();
  }
  function marquee() {
    const text = 'JAVASCRIPT • PYTHON • OPEN SOURCE • FUTMINNA • DEVELOPERS • ';
    $('#track').innerHTML = '<span>' + text.repeat(3) + '</span><span>' + text.repeat(3) + '</span>';
  }
  function reveal() {
    const els = $$('.reveal');
    if (!('IntersectionObserver' in window)) { els.forEach((e) => e.classList.add('in')); return; }
    const io = new IntersectionObserver((entries) => entries.forEach((en) => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } }), { threshold: 0.12 });
    els.forEach((e) => io.observe(e));
  }

  /* ---------- installable app (PWA) ---------- */
  function pwa() {
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator && typeof location !== 'undefined' && /^https?:$/.test(location.protocol)) {
      navigator.serviceWorker.register('sw.js').catch(() => { /* offline mode unavailable, app still works */ });
    }
    if (typeof navigator === 'undefined' || !window.addEventListener) return;
    const standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
    if (standalone) return;
    const btn = $('#install');
    let deferred = null;
    window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferred = e; btn.hidden = false; });
    btn.addEventListener('click', async () => {
      if (!deferred) return;
      deferred.prompt();
      try { await deferred.userChoice; } catch (e) { /* ignore */ }
      deferred = null; btn.hidden = true;
    });
    window.addEventListener('appinstalled', () => { btn.hidden = true; toast('App installed'); });
    const ua = navigator.userAgent || '';
    if (/iphone|ipad|ipod/i.test(ua) && !/crios|fxios/i.test(ua)) $('#ios-hint').hidden = false;
  }

  /* ---------- init ---------- */
  function init() {
    $('#api-model').value = state.model;
    $('#quick').innerHTML = ['How can I stretch my allowance?', 'Where am I overspending?', 'Plan my next month'].map((q) => '<button type="button" class="btn btn-ghost btn-sm">' + q + '</button>').join('');
    setDefaultDates(); keyStatus(); bind(); render(); renderChat();
    typing(); marquee(); reveal(); pwa();
  }
  init();
})();
