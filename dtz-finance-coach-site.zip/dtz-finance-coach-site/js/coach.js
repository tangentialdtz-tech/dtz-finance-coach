/* AI coach: OpenAI-powered answers (called straight from the browser with the
   student's own key) plus an offline rule-based fallback. */
(function (root) {
  'use strict';
  const F = root.Finance;

  const SYSTEM_PROMPT =
    'You are the DTZ TRIO Personal Finance Coach for students of the Federal University of Technology, Minna (FUTMinna), Nigeria.\n\n' +
    'Rules:\n' +
    '- Use Naira (₦). Understand student life in Minna: hostel rent, handouts and printing, data bundles, foodstuff, transport, school fees, SIWES/IT, hustles and side gigs.\n' +
    '- Base advice ONLY on the numbers in the provided financial snapshot. Never invent figures. If data is missing, say so and ask the student to log it.\n' +
    '- Be practical, encouraging, and specific: give 2-4 concrete next steps with amounts when possible.\n' +
    '- Keep answers short and easy to read on a phone.\n' +
    '- Do not recommend specific investment products, loans, betting, or crypto speculation. For anything beyond budgeting and saving basics, suggest speaking to a qualified adviser.\n' +
    '- You are a coaching tool, not a licensed financial adviser.';

  function buildContext(periodLabel, s, breakdown, goals, p) {
    const lines = [
      'Period: ' + periodLabel,
      'Income: ' + F.money(s.income),
      'Expenses: ' + F.money(s.expenses) + ' (needs ' + F.money(s.needs) + ', wants ' + F.money(s.wants) + ')',
      'Savings moved: ' + F.money(s.savings) + ' (savings rate ' + F.pct(s.savingsRate) + ')',
      'Balance left: ' + F.money(s.balance),
      'Target split needs/wants/savings: ' + p[0] + '/' + p[1] + '/' + p[2],
    ];
    if (breakdown.length) {
      lines.push('Spending by category:');
      breakdown.slice(0, 8).forEach(function (b) { lines.push('  - ' + b[0] + ': ' + F.money(b[1])); });
    }
    if (goals.length) {
      lines.push('Saving goals:');
      goals.forEach(function (g) {
        lines.push('  - ' + g.name + ': saved ' + F.money(g.saved) + ' of ' + F.money(g.target) +
          ', deadline ' + g.deadline + ', needs about ' + F.money(g.perMonth) + '/month');
      });
    }
    return lines.join('\n');
  }

  function fallbackAnswer(s, breakdown, p) {
    return F.generateTips(s, breakdown, p).map(function (t) { return '- ' + t; }).join('\n') +
      '\n\nAdd an OpenAI API key under "Coach key" to chat with the AI coach for personalised answers.';
  }

  async function ask(apiKey, model, question, context, history) {
    const messages = [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'system', content: "Student's financial snapshot:\n" + context },
    ].concat(history.slice(-8), [{ role: 'user', content: question }]);
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + apiKey },
      body: JSON.stringify({ model: model || 'gpt-4o-mini', messages: messages, temperature: 0.4, max_tokens: 500 }),
    });
    if (!res.ok) {
      let detail = '';
      try { detail = (await res.json()).error.message; } catch (e) { /* ignore */ }
      if (res.status === 401) throw new Error('invalid API key');
      if (res.status === 429) throw new Error('rate limit or no credit on this key');
      throw new Error('error ' + res.status + (detail ? ': ' + detail : ''));
    }
    const data = await res.json();
    return data.choices[0].message.content.trim();
  }

  root.Coach = { SYSTEM_PROMPT, buildContext, fallbackAnswer, ask };
})(window);
