# FUTMinna Finance Coach (installable web app)
Built by DTZ TRIO. Plain HTML, CSS and JavaScript. No build step, no server.
It is a PWA: students can install it on their phone and use it offline.

## Put it live on Netlify (2 minutes)
1. Unzip this folder.
2. Go to https://app.netlify.com/drop and sign in.
3. Drag the whole folder (the one containing `index.html`) onto the page.
4. Done. Netlify gives you an https link. Rename it under Site configuration > Change site name.

## How students install it
- Android (Chrome): tap **Install app** on the page, or Chrome menu > Install app.
- iPhone (Safari): tap Share > **Add to Home Screen**.
- Laptop (Chrome/Edge): click the install icon in the address bar.

## Notes
- Data is stored in each student's own browser. Use Download CSV in the Data tab to back up.
- The AI coach is optional: each student pastes their own OpenAI key (kept only in their browser).
  Never put your own key inside these files, because anyone could read it.
- Shipping an update: change the files, bump `CACHE = 'dtz-fc-v1'` to `v2` in `sw.js`, and drag the folder onto the site's Deploys page. Installed apps update on next open.
- Want a Play Store APK? Put your live link into pwabuilder.com and it generates the Android package.

## Files
index.html · manifest.webmanifest · sw.js · css/style.css · js/finance.js, coach.js, app.js · assets/
